#!/bin/sh

keymapfn="kipro_ce.xml"
lircmapfn="Lircmap.xml"

orig="/storage/.kodi/addons/service.kiproremote.coreelec/resources/keymap"
dest="/storage/.kodi/userdata"

orig_keymap="$orig/$keymapfn"
dest_keymap="$dest/keymaps/$keymapfn"

orig_lircmap="$orig/$lircmapfn"
dest_lircmap="$dest/$lircmapfn"

case $1 in
	"instalar")
		# Todo esto es porque ln -s requiere que no exista el archivo destino.

		# si existe el lircmap, se hace backup y borra para enlazar luego el del addon
		[ -w $dest_lircmap ] && mv $dest_lircmap $dest_lircmap.bak &> /dev/null
		rm -f $dest_lircmap &> /dev/null
		if [ -e $dest_lircmap ]
		then
			echo "ERROR: No se pudo borrar $lircmapfn"
			exit 1
		fi

		# si existe el keymap, se hace backup y se borra para enlazar luego el del addon
		[ -w $dest_keymap ] && mv $dest_keymap $dest_keymap.bak &> /dev/null
		rm -f $dest_keymap &> /dev/null
		if [ -e $dest_keymap ]
		then
			echo "ERROR: No se pudo borrar $keymapfn"
			exit 2
		fi

		ln -s $orig_lircmap $dest_lircmap &> /dev/null
		ln -s $orig_keymap $dest_keymap &> /dev/null

		/usr/bin/kodi-send -a "action(reloadkeymaps)" &> /dev/null
		echo "Keymaps instalados!"
		;;
	"desinstalar")
		rm -f $dest_lircmap 2>&1
		rm -f $dest_keymap 2>&1
		[ -e $dest_lircmap.bak ] && mv $dest_lircmap.bak $dest_lircmap
		[ -e $dest_keymap.bak ] && mv $dest_keymap.bak $dest_keymap

		sleep 1
		/usr/bin/kodi-send -a "action(reloadkeymaps)" &> /dev/null
		echo "Keymaps desinstalados!"
		;;
esac
