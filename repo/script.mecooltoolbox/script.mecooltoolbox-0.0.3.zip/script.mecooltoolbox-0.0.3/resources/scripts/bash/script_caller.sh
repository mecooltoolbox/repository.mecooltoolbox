#!/bin/sh

# Esto es ab-sur-do, pero no me quedaba otra si queria que corriera desde el addon...
# Más de media hora intentando averigüar por qué no se ejecutaba este script xD
. /storage/.kodi/addons/script.mecooltoolbox/resources/scripts/bash/_commonfuncs

cd $scripts_fcoaaron

case $1 in
	"android2oscam")
		cd cccam
			sh cccam-android.sh import
			[ -s "cccam.cfg" ] && sh cccam-oscam.sh import
			res=$?
		rm -f oscam.server cccam.cfg &> /dev/null
		return $res
	;;
	"oscam2android")
		cd cccam
			sh cccam-oscam.sh export
			[ -s "cccam.cfg" ] && sh cccam-android.sh export
			res=$?
		rm -f oscam.server cccam.cfg &> /dev/null
		return $res
	;;
	"file2oscam")
		cd cccam
			cp /tmp/cccam.cfg ./
			sh cccam-oscam.sh import
			res=$?
		rm -f /tmp/cccam.cfg oscam.server cccam.cfg &> /dev/null
		return $res
	;;
	"oscam2file")
		cd cccam
			rm -f /tmp/cccam.cfg
			sh cccam-oscam.sh export
			res=$?
			cp -f cccam.cfg /tmp
		rm -f oscam.server cccam.cfg &> /dev/null
		return $res
	;;
	"borrarclines-android") sh cccam/cccam-android.sh delete; return $? ;;
	"borrarclines-oscam") sh cccam/cccam-oscam.sh delete; return $? ;;
	"updatefromnet") sh cccam/camupg.sh; return $? ;;
	"reiniciar-oscam")
		reiniciar oscam
	;;
esac
