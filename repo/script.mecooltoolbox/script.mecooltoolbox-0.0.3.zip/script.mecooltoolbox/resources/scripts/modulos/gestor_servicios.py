#!/usr/bin/env python
# -*- coding:utf-8 -*-

from funcionescomunes import *

def main():

	def menu():

		# La versatilidad de python cada vez me asombra más, se pueden poner IFs hasta para establecer variables! toma ya...
		# Descubierto mientras buscaba cómo demonios hacer el IF en una línea xD
		oscamstat = "Iniciado" if servicio_activo(oscamsrv) else "Parado"
		tvhstat = "Iniciado" if servicio_activo(tvhsrv) else "Parado"

		opts = [
		"*** Estado actual ***", # 0
		"OSCam : "+oscamstat, #1
		"TvHeadend : "+tvhstat, #2
		"", #3
		"Reiniciar OSCam", #4
		"Parar OSCam", #5
		"", #6
		"Reiniciar TvHeadend", #7
		"Parar TvHeadend", #8
		"", #9
		"Reiniciar Kodi"] #10

		return sel("Gestor de servicios",opts)

	# Esto ejecutará el menú en bucle hasta que el usuario decida salir dando a Cancelar o al botón atrás, momento en que se cumplirá que res es -1
	res=0
	while res != -1:

		res = menu()

		if res == 4: servicio_reiniciar(oscamsrv); msg("Hecho!","OSCam reiniciado!")
		if res == 5: servicio_parar(oscamsrv); msg("Hecho!","OSCam parado!")

		if res == 7: servicio_reiniciar(tvhsrv); msg("Hecho!","TvHeadend reiniciado!")
		if res == 8: servicio_parar(tvhsrv); msg("Hecho!","TvHeadend parado!")

		if res == 10:
			if msgyn("Confirmación","Esto hará un reinicio suave de Kodi, por lo que la pantalla se pondrá en negro por unos segundos, quiere continuar?") == 1:
				servicio_reiniciar("kodi")