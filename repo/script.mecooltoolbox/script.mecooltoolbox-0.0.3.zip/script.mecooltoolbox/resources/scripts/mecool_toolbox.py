#!/usr/bin/env python
# -*- coding:utf-8 -*-

import xbmcaddon
ADDON = xbmcaddon.Addon()
addon_name = ADDON.getAddonInfo('name')

from modulos.funcionescomunes import *
from modulos.oscam_toolbox_funcs import *

import modulos.gestor_servicios

def menu(): # Super-menú xD

	opts = [
	"*** Importar/Exportar/Borrar clines ***", # 0
	"Importar desde Archivo", #1
	"Exportar hacia Archivo", #2
	"Borrar clines de OSCam", #3
	"-------------------------------------", #4
	"Importar desde Android", #5
	"Exportar hacia Android", #6
	"Borrar clines de Android", #7
	"", #8
	"*** Backup completo OSCam ***", #9
	"Backup OSCam", #10
	"Restaurar OSCam", #11
	"", #12
	"*** Lista M3U ***", #13
	"Configurar parámetros de lista remota",#14
	"Generar lista M3U local",#15
	"Generar lista M3U remota",#16
	"",#17
	"Editor de clines", #18
	"Gestor de servicios", #19
	"", #20
	"Información"] #21

	return sel(addon_name,opts)

# Esto ejecutará el menú en bucle hasta que el usuario decida salir dando a Cancelar o al botón atrás, momento en que se cumplirá que res es -1
res=0
while res != -1:
	res = menu()

	if res == 1: file2oscam() # Importar de Archivo a OSCam
	if res == 2: oscam2file() # Exportar de OSCam a Archivo
	if res == 3: borrar_clines_oscam() # Borrar clines de OSCam

	if res == 5: android2oscam()  # Importar desde Android
	if res == 6: oscam2android() # Exportar hacia Android
	if res == 7: borrar_clines_android() # Borrar clines de Android

	if res == 10: oscam_backup() # Backup de OSCam
	if res == 11: oscam_restore() # Restaurar backup de OSCam

	if res == 14: config_m3u_params()
	if res == 15: generar_m3u_local()
	if res == 16: generar_m3u_remoto()

	if res == 18: editor_clines()
	if res == 19: modulos.gestor_servicios.main() # Llamamos directamente al otro script, en el que englobé todo su código en la función main :)

	if res == 21: info()
else:
	exit()
